function Function() {
    document.getElementById("lnav").style.display = "block";
}